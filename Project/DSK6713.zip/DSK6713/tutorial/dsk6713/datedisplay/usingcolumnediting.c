
// ****************************************************************
// Description: This file is used to primarly showcase the column
// editing features of Code Composer Studio
// ****************************************************************

// Declare two arrays
int set_one[] = { 	1,	2,
					3,	4,
					5,	6,
					7,	8 };
					

