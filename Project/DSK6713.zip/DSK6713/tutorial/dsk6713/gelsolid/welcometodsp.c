
// ********************************************
// Sample DSP application used to showcase GEL 
// automation
// ********************************************

#include <stdio.h>

void main()
{
	printf("Welcome to the World of DSP");
}


	
