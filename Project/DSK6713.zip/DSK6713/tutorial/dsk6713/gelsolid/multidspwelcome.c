
// ********************************************
// Sample DSP application used to showcase GEL 
// components controlling DSP code
// ********************************************

#include <stdio.h>
#define TRUE 1

int counterValue = 0;

void main()
{
	while (TRUE) {
		printf("Welcome to the World of DSP. %d\n", counterValue );
	}
	
}


	
