#define SIZE_SINE_TABLE 128

extern int sineTable[SIZE_SINE_TABLE];


