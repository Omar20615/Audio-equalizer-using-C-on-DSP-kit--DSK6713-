
#define SIZE_SHAPING_FILTER 255

extern int raisedCosineTable[SIZE_SHAPING_FILTER];
                                                  
                                                  
                                                  
